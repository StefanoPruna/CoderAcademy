# Stefano's portfolio-website

[Link]https://stefanoportfolio.netlify.app

### This website is meant to be my extended Resume, with more details about my work and experience.
#### In the website you will find:
     1. Example of some of my projects with their source codes.
    
     2. My updated **Resume** can **Cover Letter** that will *pop down* when hover the picture
    
     3. I have created a menu that will *slide* in.
    
     4. links to my GitHub and Linkedin pages:
        a. [GitHub]https://github.com/StefanoPruna)
        b. https://www.linkedin.com/in/stefano-pruna-0228b349
    
    5. A contact page with the following:
        a. Write me an email;
        b. My address;
        c. GitHub and Linkedin links again.
    
    6. I have used HTML, CSS, JavaScript to build the website

